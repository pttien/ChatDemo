﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.Identity;
using WebApplication1.Models;


namespace WebApplication1.Hubs
{
    [Authorize]
    public class Chat : Hub
    {
        private readonly static ConnectionMapping<string> _connections =
            new ConnectionMapping<string>();

        public void SendChatMessage(string who, string message)
        {
            string name = Context.User.Identity.Name;

            //Clients.User(who).addChatMessage(name, message);
            foreach (var connectionId in _connections.GetConnections(who))
            {
                Clients.Client(connectionId).addChatMessage(name, message);
            }
        }

        public override Task OnConnected()
        {
            string name = Context.User.Identity.Name;

            _connections.Add(name, Context.ConnectionId);

            Clients.All.joined(_connections.GetAllUser());

            return base.OnConnected();
        }

        public override Task OnDisconnected(bool a)
        {
            string name = Context.User.Identity.Name;

            _connections.Remove(name, Context.ConnectionId);

            Clients.All.joined(_connections.GetAllUser());

            return base.OnDisconnected(a);
        }

        public override Task OnReconnected()
        {
            string name = Context.User.Identity.Name;

            if (!_connections.GetConnections(name).Contains(Context.ConnectionId))
            {
                _connections.Add(name, Context.ConnectionId);
            }

            return base.OnReconnected();
        }
        //public override Task OnConnected()
        //{
     
        //    var test = Context.User.Identity.Name;
        //    return Clients.All.joined(Context.User.Identity.Name,Context.ConnectionId);
            
        //}
        //public override Task OnReconnected()
        //{
        //    return base.OnReconnected();
        //}
        //public void Send(string message, string groupName, string userSent)
        //{
        //    if (Clients != null)
        //    {
        //        Clients.Group(groupName).addMessage(message, groupName, userSent);
        //    }
        //}

        //public List<string> GetAllUserOnline()
        //{
        //    return new List<string>();
        //}
        //public void CreateGroup(string userTo, string connectionId)
        //{
        //    string strGroupName = Context.User.Identity.Name + userTo;
        //    Groups.Add(Context.ConnectionId, strGroupName);
        //    Groups.Add(connectionId, strGroupName);
        //    Clients.Caller.setChatWindow(strGroupName, userTo);
        //}

        //private string GetUniqueGroupName(string currentUserId, string toConnectTo)
        //{
        //    return (currentUserId.GetHashCode() ^ toConnectTo.GetHashCode()).ToString();
        //}
    }
}