

var windowFocus = true;
var chatHeartbeatCount = 0;
var minChatHeartbeat = 1000;
var maxChatHeartbeat = 33000;
var chatHeartbeatTime = minChatHeartbeat;
var originalTitle;
var blinkOrder = 0;

var chatboxFocus = new Array();
var newMessages = new Array();
var newMessagesWin = new Array();
var chatBoxes = new Array();

$(document).ready(function () {
    originalTitle = document.title;

    $([window, document]).blur(function () {
        windowFocus = false;
    }).focus(function () {
        windowFocus = true;
        document.title = originalTitle;
    });
});

function restructureChatBoxes() {
    align = 0;
    for (x in chatBoxes) {
        chatboxtitle = chatBoxes[x];

        if ($("#chatbox_" + chatboxtitle).css('display') != 'none') {
            if (align == 0) {
                $("#chatbox_" + chatboxtitle).css('right', '230px');
            } else {
                width = (align) * (225 + 7) + 230;
                $("#chatbox_" + chatboxtitle).css('right', width + 'px');
            }
            align++;
        }
    }
}
function chatWith(userTo) {
    createChatBox(userTo);
    $("#chatbox_" + userTo + " .chatboxtextarea").focus();
}

function createChatBox(chatboxtitle) {
    if ($("#chatbox_" + chatboxtitle).length > 0) {
        if ($("#chatbox_" + chatboxtitle).css('display') == 'none') {
            $("#chatbox_" + chatboxtitle).css('display', 'block');
            restructureChatBoxes();
        }
        $("#chatbox_" + chatboxtitle + " .chatboxtextarea").focus();
        return;
    }

    $(" <div />").attr("id", "chatbox_" + chatboxtitle)
	.addClass("chatbox")
	.html('<div class="chatboxhead"><div class="chatboxtitle">' + chatboxtitle
    + '</div><div class="chatboxoptions"><a href="javascript:void(0)" onclick="javascript:toggleChatBoxGrowth(\''
    + chatboxtitle + '\')">-</a> <a href="javascript:void(0)" onclick="javascript:closeChatBox(\'' + chatboxtitle + '\')">X</a></div><br clear="all"/></div><div class="chatboxcontent"></div><div class="chatboxinput"><textarea class="chatboxtextarea" onkeydown="javascript:return checkChatBoxInputKey(event,this,\'' + chatboxtitle + '\');"></textarea></div>')
	.appendTo($("body"));

    $("#chatbox_" + chatboxtitle).css('bottom', '0px');

    chatBoxeslength = 0;

    for (x in chatBoxes) {
        if ($("#chatbox_" + chatBoxes[x]).css('display') != 'none') {
            chatBoxeslength++;
        }
    }

    if (chatBoxeslength == 0) {
        $("#chatbox_" + chatboxtitle).css('right', '230px');
    } else {
        width = (chatBoxeslength) * (225 + 7) + 230;
        $("#chatbox_" + chatboxtitle).css('right', width + 'px');
    }

    chatBoxes.push(chatboxtitle);

  

    chatboxFocus[chatboxtitle] = false;

    $("#chatbox_" + chatboxtitle + " .chatboxtextarea").blur(function () {
        chatboxFocus[chatboxtitle] = false;
        $("#chatbox_" + chatboxtitle + " .chatboxtextarea").removeClass('chatboxtextareaselected');
    }).focus(function () {
        chatboxFocus[chatboxtitle] = true;
        newMessages[chatboxtitle] = false;
        $('#chatbox_' + chatboxtitle + ' .chatboxhead').removeClass('chatboxblink');
        $("#chatbox_" + chatboxtitle + " .chatboxtextarea").addClass('chatboxtextareaselected');
    });

    $("#chatbox_" + chatboxtitle).click(function () {
        if ($('#chatbox_' + chatboxtitle + ' .chatboxcontent').css('display') != 'none') {
            $("#chatbox_" + chatboxtitle + " .chatboxtextarea").focus();
        }
    });

    $("#chatbox_" + chatboxtitle).show();
}



function closeChatBox(chatboxtitle) {
    $('#chatbox_' + chatboxtitle).css('display', 'none');
    restructureChatBoxes();

}

function toggleChatBoxGrowth(chatboxtitle) {
    if ($('#chatbox_' + chatboxtitle + ' .chatboxcontent').css('display') == 'none') {


        $('#chatbox_' + chatboxtitle + ' .chatboxcontent').css('display', 'block');
        $('#chatbox_' + chatboxtitle + ' .chatboxinput').css('display', 'block');
        $("#chatbox_" + chatboxtitle + " .chatboxcontent").scrollTop($("#chatbox_" + chatboxtitle + " .chatboxcontent")[0].scrollHeight);
    } else {

        $('#chatbox_' + chatboxtitle + ' .chatboxcontent').css('display', 'none');
        $('#chatbox_' + chatboxtitle + ' .chatboxinput').css('display', 'none');
    }

}

function checkChatBoxInputKey(event, chatboxtextarea, chatboxtitle) {
    
    if (event.keyCode == 13 && event.shiftKey == 0) {
        message = $(chatboxtextarea).val();
        if (message != null) {
            //$.post('/Chat/',
            //    { message: message, username: chatboxtitle.val() }, function (data) {
            //});
            var chat = $.connection.chat;
            $.connection.hub.start().done(function () {
                chat.server.sendChatMessage(chatboxtitle, message);
            });
            $(chatboxtextarea).val('');
            $("#chatbox_" + chatboxtitle + " .chatboxcontent").append('<div class="chatboxmessage"><span class="chatboxmessagefrom">' + $('#userName').text() + ':&nbsp;&nbsp;</span><span class="chatboxmessagecontent">' + message + '</span></div>');
            $("#chatbox_" + chatboxtitle + " .chatboxcontent").scrollTop($("#chatbox_" + chatboxtitle + " .chatboxcontent")[0].scrollHeight);
            
        }

    }
}
