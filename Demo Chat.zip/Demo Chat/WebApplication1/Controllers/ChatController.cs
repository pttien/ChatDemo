﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class ChatController : Controller
    {
        //
        // GET: /Chat/
        public ActionResult Index()
        {
            return View();
        }

        //public ActionResult LoadUserListOnline()
        //{
        //    List<User> userList = OnlineUser.InitUser();
        //    return PartialView("_ListUserOnline", userList);
        //}

        //[HttpPost]
        //public ActionResult UpdateUser(string userName, string connectionId)
        //{
        //    var userOnline = OnlineUser.userObj.Where(u => u.username == userName).FirstOrDefault();
        //    userOnline.connectionId = connectionId;
        //    return Json(new { success = true }, JsonRequestBehavior.AllowGet);
        //}
	}
}